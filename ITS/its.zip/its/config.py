PYTHON_BASICS = {
    "NAME": "Fondamenti di Programmazione in Python",
    "DIFFICULTY": 5,
    "DURATION": 250,
    "SUBJECTS": ["Python", "Programmazione", "If", "Variabile"]
}

PYTHON_CLASSES = {
    "NAME": "Classi in Python",
    "DIFFICULTY": 9999,
    "DURATION": 120,
    "SUBJECTS": ["Python", "Programmazione", "Classi", "Programmazione a Oggetti"]
}